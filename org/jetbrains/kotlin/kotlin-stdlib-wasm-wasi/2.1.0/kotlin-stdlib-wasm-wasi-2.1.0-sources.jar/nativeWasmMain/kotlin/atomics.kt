/*
 * Copyright 2010-2024 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package kotlin.concurrent

internal expect class AtomicReference<T>(value: T) {
    public var value: T
    public fun compareAndExchange(expected: T, newValue: T): T
    public fun compareAndSet(expected: T, newValue: T): Boolean
}
